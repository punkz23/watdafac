from django.apps import AppConfig


class AffectedfamilyConfig(AppConfig):
    name = 'affectedFamily'
