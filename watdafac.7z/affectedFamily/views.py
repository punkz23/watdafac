from django.shortcuts import render
from django.http import HttpResponse
# from .forms import familyheadForm


# def familyhead(request):

#     form = familyheadForm()
#     return render(request, 'form.html', {'form': form})
